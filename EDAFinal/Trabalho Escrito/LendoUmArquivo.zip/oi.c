//Código por Aurelio Grott monitor de Estrutura de Dados - UDESC CCT - 2016
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SUCESSO 1
#define FRACASSO 0
#define tamString 100

typedef struct
{
    int matricula;
    char nome[tamString];
    int telefone;
    float salario;
    int idade;
    char departamento[tamString];
} Registro;

FILE* le_arquivo(FILE *fp, Registro *busca) //efetua leitura de uma struct completa no arquivo e retorna FILE* para analise e controle
{
	fscanf(fp,"%d\n",&(busca->matricula));
	fgets(busca->nome,tamString, fp);
	fscanf(fp,"%d\n",&(busca->telefone));
	fscanf(fp,"%f\n",&(busca->salario));
	fscanf(fp,"%d\n",&(busca->idade));
	fgets(busca->departamento,tamString, fp);
	return fp;
}

int pesquisa_no_arquivo(FILE *fp, int matricula, Registro *busca)//efetua busca de um Registro no arquivo pelo numero de matricula
{
	while(!feof(le_arquivo(fp, busca)) && (busca->matricula != matricula));
	return busca->matricula == matricula ? SUCESSO : FRACASSO; 
}

int main()
{
	FILE *fp = fopen("oi.txt","r");
	Registro reg;
		
	printf("-----------comeco oi.txt-----------\n");
	while(!feof(le_arquivo(fp,&reg)))
		printf("%d\n%s\n%d\n%f\n%d\n%s\n", reg.matricula,reg.nome,reg.telefone,reg.salario,reg.idade,reg.departamento);
	printf("------------fim oi.txt-------------\n\n\n");
	
	rewind(fp);
	
	printf("-----------comeco pesquisa-----------\n");
	pesquisa_no_arquivo(fp, 789987, &reg) ? printf("%d\n%s\n%d\n%f\n%d\n%s\n", reg.matricula,reg.nome,reg.telefone,reg.salario,reg.idade,reg.departamento) : printf(">>Esto non ecziste!\n");
	printf("------------fim pesquisa-------------\n");
	
	return 0;
}
